
class operaciones:
    def suma(self,a,b):
        return a+b
    def resta(self,a,b):
        return a-b
    def multiplicacion(self,a,b):
        return a*b
    def division(self,a,b):
        return a/b
            
            
            