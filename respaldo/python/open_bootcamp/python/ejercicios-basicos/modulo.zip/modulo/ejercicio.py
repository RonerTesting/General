from calculadora import operaciones

calculador = operaciones()
print(calculador.suma(1,2))
print(calculador.resta(2,3))
print(calculador.multiplicacion(3,4))
print(calculador.division(5,6))

